
public class a1 {
	public static void main(String[] args) {
		String a ="*    * ***** *     *      ****" ;
		String b ="*    * *     *     *     *    *" ;
		String c ="****** ***** *     *     *    *" ;
		String d ="*    * *     *     *     *    *" ;
		String e ="*    * ***** ***** *****  ****" ;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		}

}
